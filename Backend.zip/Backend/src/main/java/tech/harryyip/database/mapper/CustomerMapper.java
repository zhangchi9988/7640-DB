package tech.harryyip.database.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import tech.harryyip.database.entity.Customer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Mapper
public interface CustomerMapper extends BaseMapper<Customer> {

    @Insert("INSERT INTO customer(telephone_number, address) VALUES(#{telephoneNumber}, #{address})")
    @Options(useGeneratedKeys=true, keyProperty="customerId")
    void insertCustomer(Customer customer);

}
