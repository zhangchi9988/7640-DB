package tech.harryyip.database.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import tech.harryyip.database.service.ItemService;
import tech.harryyip.database.vo.R;
import tech.harryyip.database.vo.REnum;

import java.math.BigDecimal;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Api("Item API")
@RestController
@RequestMapping("/item")
public class ItemController {

    @Autowired
    ItemService itemService;

    @ApiOperation("Add an item to a shop")
    @PostMapping("/addItem")
    public R addItem(@RequestParam Integer shopId, @RequestParam String itemName,
                     @RequestParam BigDecimal price, @RequestParam(required = false) String keyword1,
                     @RequestParam(required = false) String keyword2, @RequestParam(required = false) String keyword3) {
        if (itemService.addItem(shopId, itemName, price, keyword1, keyword2, keyword3)) {
            return R.success();
        } else {
            return R.error(REnum.ADD_ITEM_FAILED);
        }
    }

    @ApiOperation("Show items")
    @GetMapping("/showItems/{shopId}")
    public R showItems(@PathVariable Integer shopId) {
        return R.success(itemService.showItems(shopId));
    }

    @ApiOperation("Search items")
    @GetMapping("/searchItems")
    public R searchItems(@RequestParam String input) {
        return R.success(itemService.searchItems(input));
    }

}

