package tech.harryyip.database.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import tech.harryyip.database.entity.Customer;
import tech.harryyip.database.mapper.CustomerMapper;
import tech.harryyip.database.service.CustomerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Service
public class CustomerServiceImpl extends ServiceImpl<CustomerMapper, Customer> implements CustomerService {

    @Autowired
    CustomerMapper customerMapper;

    @Override
    public Integer signUp(String telephone, String address) {
        Customer customer = new Customer();
        customer.setAddress(address);
        customer.setTelephoneNumber(telephone);
        customerMapper.insertCustomer(customer);
        return customer.getCustomerId();
    }

    @Override
    public boolean isValidCustomer(Integer customerId) {
        if (this.getById(customerId) != null) {
            return true;
        }
        return false;
    }
}
