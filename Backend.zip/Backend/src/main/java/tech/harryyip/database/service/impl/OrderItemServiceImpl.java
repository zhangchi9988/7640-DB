package tech.harryyip.database.service.impl;

import tech.harryyip.database.entity.OrderItem;
import tech.harryyip.database.mapper.OrderItemMapper;
import tech.harryyip.database.service.OrderItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Service
public class OrderItemServiceImpl extends ServiceImpl<OrderItemMapper, OrderItem> implements OrderItemService {

}
