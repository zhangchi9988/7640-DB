package tech.harryyip.database.service;

import tech.harryyip.database.entity.Customer;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
public interface CustomerService extends IService<Customer> {

    public Integer signUp(String telephone, String address);

    public boolean isValidCustomer(Integer customerId);

}
