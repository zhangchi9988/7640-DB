package tech.harryyip.database.mapper;

import tech.harryyip.database.entity.Item;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Mapper
public interface ItemMapper extends BaseMapper<Item> {

}
