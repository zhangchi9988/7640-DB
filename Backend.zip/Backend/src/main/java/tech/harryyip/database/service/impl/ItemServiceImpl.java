package tech.harryyip.database.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import tech.harryyip.database.entity.Item;
import tech.harryyip.database.mapper.ItemMapper;
import tech.harryyip.database.service.ItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Service
public class ItemServiceImpl extends ServiceImpl<ItemMapper, Item> implements ItemService {

    @Override
    public boolean addItem(Integer shopId, String itemName, BigDecimal price, String keyword1, String keyword2, String keyword3) {
        Item item = new Item(shopId, itemName, price, keyword1, keyword2, keyword3);
        return this.save(item);
    }

    @Override
    public List<Item> showItems(Integer shopId) {
        return this.list(new QueryWrapper<Item>().eq("shop_id", shopId));
    }

    @Override
    public List<Item> searchItems(String input) {
        QueryWrapper<Item> qw = new QueryWrapper<>();
        qw.eq("name", input).or()
                .eq("keyword1", input).or()
                .eq("keyword2", input).or()
                .eq("keyword3", input);
        return this.list(qw);
    }
}
