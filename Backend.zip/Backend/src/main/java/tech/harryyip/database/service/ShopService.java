package tech.harryyip.database.service;

import tech.harryyip.database.entity.Shop;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
public interface ShopService extends IService<Shop> {
    public boolean addShop(String shopName, String location);
    public List<Shop> showShops();
}
