package tech.harryyip.database.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Getter
@Setter
@ApiModel(value = "OrderItem对象", description = "")
public class OrderItem implements Serializable {

    @ApiModelProperty("Auto increment id of order_item")
    @TableId(value = "order_item_id", type = IdType.AUTO)
    private Integer orderItemId;

    @ApiModelProperty("Order ID")
    private Integer orderId;

    @ApiModelProperty("Item ID")
    private Integer itemId;

    @ApiModelProperty("Quantity of the item that customer buy")
    private Integer quantity;

}
