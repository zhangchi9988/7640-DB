package tech.harryyip.database.service;

import tech.harryyip.database.entity.Order;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
public interface OrderService extends IService<Order> {

    public void newOrder(Integer customerId, List<List<Integer>> items);

    public void cancelOrderItems(Integer orderId, List<Integer> items);
}
