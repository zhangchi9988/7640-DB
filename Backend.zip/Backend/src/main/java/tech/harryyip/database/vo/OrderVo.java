package tech.harryyip.database.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel("View object of order, to input an order")
public class OrderVo {

    @ApiModelProperty("Items that user bought")
    private List<List<Integer>> items;

}
