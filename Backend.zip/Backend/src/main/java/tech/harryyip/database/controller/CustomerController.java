package tech.harryyip.database.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tech.harryyip.database.service.CustomerService;
import tech.harryyip.database.vo.R;
import tech.harryyip.database.vo.REnum;

import javax.servlet.http.HttpSession;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Api("Customer API")
@RestController
@RequestMapping("/")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @ApiOperation("Sign up")
    @PostMapping("/signUp")
    public R signUp(HttpSession session, @RequestParam String telephone, @RequestParam String address) {
        int cId = customerService.signUp(telephone, address);
        session.setAttribute("customerId", cId);
        return R.success(cId);
    }

    @ApiOperation("Sign in")
    @PostMapping("/signIn")
    public R signIn(HttpSession session, @RequestParam Integer customerId) {
        if (session.getAttribute("customerId") != null && session.getAttribute("customerId").equals(customerId)) {
            return R.error(REnum.LOGIN_BEFORE);
        } else if (customerService.isValidCustomer(customerId)) {
            session.setAttribute("customerId", customerId);
            return R.success();
        } else {
            return R.error(REnum.NO_CUSTOMER_ERROR);
        }
    }

    @ApiOperation("Log out")
    @PostMapping("/logOut")
    public R logOUt(HttpSession session) {
        Integer cId = (Integer) session.getAttribute("customerId");
        if (cId != null) {
            session.removeAttribute("customerId");
            return R.success();
        }
        return R.error(REnum.NOT_LOGIN_ERROR);
    }

}

