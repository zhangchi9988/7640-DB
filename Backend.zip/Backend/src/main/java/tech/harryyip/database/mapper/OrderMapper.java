package tech.harryyip.database.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import tech.harryyip.database.entity.Customer;
import tech.harryyip.database.entity.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Mapper
public interface OrderMapper extends BaseMapper<Order> {

    @Insert("INSERT INTO `order`(customer_id) VALUES(#{customerId})")
    @Options(useGeneratedKeys=true, keyProperty="orderId")
    void insertOrder(Order order);

}
