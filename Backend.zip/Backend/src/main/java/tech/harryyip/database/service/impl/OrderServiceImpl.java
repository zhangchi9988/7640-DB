package tech.harryyip.database.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import tech.harryyip.database.entity.Order;
import tech.harryyip.database.entity.OrderItem;
import tech.harryyip.database.mapper.OrderMapper;
import tech.harryyip.database.service.OrderItemService;
import tech.harryyip.database.service.OrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {

    @Autowired
    OrderItemService orderItemService;

    @Autowired
    OrderMapper orderMapper;

    @Override
    public void newOrder(Integer customerId, List<List<Integer>> items) {
        Order order = new Order();
        order.setCustomerId(customerId);
        orderMapper.insertOrder(order);
        int oId = order.getOrderId();

        for (List<Integer> itemSet : items) {
            OrderItem oi = new OrderItem();
            oi.setItemId(itemSet.get(0));
            oi.setQuantity(itemSet.get(1));
            oi.setOrderId(oId);
            orderItemService.save(oi);
        }

    }

    @Override
    public void cancelOrderItems(Integer orderId, List<Integer> items) {
        for (Integer item : items) {
            orderItemService.remove(new QueryWrapper<OrderItem>().eq("item_id", item).eq("order_id", orderId));
        }
    }
}
