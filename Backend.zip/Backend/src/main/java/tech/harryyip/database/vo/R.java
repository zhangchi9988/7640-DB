package tech.harryyip.database.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class R {

    private long code;
    private String msg;
    private Object obj;

    public static R success() {
        return new R(tech.harryyip.database.vo.REnum.SUCCESS.getCode(), tech.harryyip.database.vo.REnum.SUCCESS.getMessage(), null);
    }
    public static R success(Object obj) {
        return new R(tech.harryyip.database.vo.REnum.SUCCESS.getCode(), tech.harryyip.database.vo.REnum.SUCCESS.getMessage(), obj);
    }

    // success返回都一样，但是失败的时候有很多情况，所以直接传入REnum
    public static R error(tech.harryyip.database.vo.REnum re) {
        return new R(re.getCode(), re.getMessage(), null);
    }

    public static R error(tech.harryyip.database.vo.REnum re, Object obj) {
        return new R(re.getCode(), re.getMessage(), obj);
    }
}
