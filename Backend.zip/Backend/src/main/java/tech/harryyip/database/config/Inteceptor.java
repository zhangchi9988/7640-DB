package tech.harryyip.database.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

@Configuration
class Interceptor extends WebMvcConfigurer {

    @Bean
    LoginAuthInterceptor loginAuthInterceptor() {
        return new LoginAuthInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 添加一个拦截器，排除登录url
        registry.addInterceptor(loginAuthInterceptor())
                .addPathPatterns("/order/newOrder")
                .addPathPatterns("/order/showOrder")
                .addPathPatterns("/order/cancelOrder");
    }
}