package tech.harryyip.database.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@RestController
@RequestMapping("/database/orderItem")
public class OrderItemController {

}

