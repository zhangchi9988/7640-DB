package tech.harryyip.database.vo;

import io.swagger.models.auth.In;
import lombok.Data;

import java.util.List;

@Data
public class CancelOrderVo {

    private Integer orderId;

    private List<Integer> items;

}
