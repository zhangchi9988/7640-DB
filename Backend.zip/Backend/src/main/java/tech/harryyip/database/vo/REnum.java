package tech.harryyip.database.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@Getter
public enum REnum {
    // General
    SUCCESS(200, "Success"),
    ERROR(500, "Server Error"),

    // Shop
    ADD_SHOP_FAILED(500501, "Add shop failed."),

    // Item
    ADD_ITEM_FAILED(500511, "Add item to shop failed!"),

    // Customer
    NOT_LOGIN_ERROR(500521, "Not login yet."),
    NO_CUSTOMER_ERROR(500522, "The id is not registered."),
    LOGIN_BEFORE(500523, "You have login before.")
    ;

    private final Integer code;
    private final String message;
}
