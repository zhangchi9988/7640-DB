package tech.harryyip.database.controller;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import tech.harryyip.database.service.OrderService;
import tech.harryyip.database.service.impl.OrderServiceImpl;
import tech.harryyip.database.vo.CancelOrderVo;
import tech.harryyip.database.vo.OrderVo;
import tech.harryyip.database.vo.R;

import javax.servlet.http.HttpSession;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Api("Order API")
@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    OrderService orderService;

    @ApiOperation("Make a new order, which may consist of several items")
    @PostMapping("/newOrder")
    public R newOrder(HttpSession session, @RequestBody OrderVo orderVo) {
        orderService.newOrder((Integer) session.getAttribute("customerId"), orderVo.getItems());
        return R.success(orderVo);
    }

    @ApiOperation("Remove order, which may not contains all items in an order")
    @PostMapping("/cancelOrder")
    public R cancelOrder(@RequestBody CancelOrderVo cancelOrderVo) {
        orderService.cancelOrderItems(cancelOrderVo.getOrderId(), cancelOrderVo.getItems());
        return R.success();
    }

}

