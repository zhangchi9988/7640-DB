package tech.harryyip.database.service;

import org.springframework.web.bind.annotation.RequestParam;
import tech.harryyip.database.entity.Item;
import com.baomidou.mybatisplus.extension.service.IService;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
public interface ItemService extends IService<Item> {

    public boolean addItem(Integer shopId, String itemName, BigDecimal price, String keyword1,
                           String keyword2, String keyword3);

    public List<Item> showItems(Integer shopId);

    public List<Item> searchItems(String input);
}
