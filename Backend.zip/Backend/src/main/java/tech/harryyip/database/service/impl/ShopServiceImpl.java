package tech.harryyip.database.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import tech.harryyip.database.entity.Shop;
import tech.harryyip.database.mapper.ShopMapper;
import tech.harryyip.database.service.ShopService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Service
public class ShopServiceImpl extends ServiceImpl<ShopMapper, Shop> implements ShopService {

    @Autowired ShopMapper shopMapper;

    @Override
    public boolean addShop(String shopName, String location) {
        Shop shop = new Shop();
        shop.setShopName(shopName);
        shop.setLocation(location);
        return this.save(shop);
    }

    @Override
    public List<Shop> showShops() {
        QueryWrapper<Shop> queryWrapper = new QueryWrapper<>();
        return shopMapper.selectList(queryWrapper);
    }

}
