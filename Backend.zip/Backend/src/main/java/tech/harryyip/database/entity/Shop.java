package tech.harryyip.database.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Getter
@Setter
@ApiModel(value = "Shop对象", description = "")
public class Shop implements Serializable {

    @ApiModelProperty("Shop ID")
    @TableId(value = "shop_id", type = IdType.AUTO)
    private Integer shopId;

    @ApiModelProperty("Name of the shop")
    private String shopName;

    @ApiModelProperty("Rating ot the shop")
    private Float rating;

    @ApiModelProperty("Location of the shop")
    private String location;


}
