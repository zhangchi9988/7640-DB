package tech.harryyip.database.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Getter
@Setter
@ApiModel(value = "Item对象", description = "")
public class Item implements Serializable {

    @ApiModelProperty("Item id")
    @TableId(value = "item_id", type = IdType.AUTO)
    private Integer itemId;

    @ApiModelProperty("Belongs to which shop")
    private Integer shopId;

    @ApiModelProperty("Name of the item")
    private String name;

    @ApiModelProperty("Price of the item")
    private BigDecimal price;

    @ApiModelProperty("Keyword 1")
    private String keyword1;

    @ApiModelProperty("Keyword 2")
    private String keyword2;

    @ApiModelProperty("Keyword 3")
    private String keyword3;

    public Item(Integer shopId, String itemName, BigDecimal price, String keyword1, String keyword2, String keyword3) {
        this.shopId = shopId;
        this.name = itemName;
        this.price = price;
        this.keyword1 = keyword1;
        this.keyword2 = keyword2;
        this.keyword3 = keyword3;
    }
    public Item(){}

}
