package tech.harryyip.database.controller;


import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import tech.harryyip.database.service.ShopService;
import tech.harryyip.database.vo.R;
import tech.harryyip.database.vo.REnum;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@RestController
@RequestMapping("/shop")
@Api(value = "Shop API")
public class ShopController {

    @Autowired
    ShopService shopService;

    @GetMapping("/test")
    public R test() {
        return R.success();
    }

    @ApiOperation("Show all the shops")
    @GetMapping("/showShops")
    public R showShops() {
        return R.success(shopService.showShops());
    }

    @ApiOperation("Add a shop")
    @PostMapping("/addShop")
    public R addShop(@RequestParam(value = "shopName") String shopName,
                     @RequestParam(value = "location") String location) {
        if (shopService.addShop(shopName, location)) {
            return R.success();
        } else {
            return R.error(REnum.ADD_SHOP_FAILED);
        }
    }

}

