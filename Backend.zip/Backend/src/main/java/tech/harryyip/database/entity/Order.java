package tech.harryyip.database.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author Harry
 * @since 2023-04-03
 */
@Getter
@Setter
@ApiModel(value = "Order Model")
public class Order implements Serializable {

    @ApiModelProperty("Order ID")
    @TableId(value = "order_id", type = IdType.AUTO)
    private Integer orderId;

    @ApiModelProperty("Customer Id")
    private Integer customerId;


}
