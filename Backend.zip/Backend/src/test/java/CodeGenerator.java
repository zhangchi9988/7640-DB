import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import org.junit.Test;

/**
 * @author
 * @since 2018/12/13
 */
public class CodeGenerator {

    @Test
    public void codeGenerate() {
        String projectPath = System.getProperty("user.dir");

        FastAutoGenerator.create("jdbc:mysql://localhost:3306/Database?serverTimezone=GMT%2B8", "root", "12345666")
            .globalConfig(builder -> {
                builder.author("Harry") // 设置作者
                    .enableSwagger() // 开启 swagger 模式
//                    .fileOverride() // 覆盖已生成文件
                    .outputDir(projectPath + "/src/main/java"); // 指定输出目录
            })
            .packageConfig(builder -> {
                builder.parent("tech.harryyip") // 设置父包名
                        .moduleName("database"); // 设置父包模块名
//                        .pathInfo(Collections.singletonMap(OutputFile.mapperXml, "D://")); // 设置mapperXml生成路径
            })
            .strategyConfig(builder -> {
//                builder.addInclude("t_user", "user_fav_hate") // 设置需要生成的表名
                builder.addInclude("shop", "customer", "order", "item", "order_item") // 设置需要生成的表名
                        .enableSchema()
//                        .addTablePrefix("t_", "c_") // 设置过滤表前缀
                        // service策略配置
                        .serviceBuilder()
                        .formatServiceFileName("%sService")         // 格式化 service 接口文件名称
                        .formatServiceImplFileName("%sServiceImpl")
                        // entity策略配置
                        .entityBuilder()
                        .naming(NamingStrategy.underline_to_camel)
                        .enableLombok()
//                        .idType(IdType.ASSIGN_UUID)   // id 类型
//                        .logicDeleteColumnName("deleted") // 逻辑删除标志
//                        .addTableFills(
//                                new Column("gmt_create", FieldFill.INSERT),
//                                new Column("gmt_update", FieldFill.INSERT_UPDATE)
//                                )
                        // controller策略配置
                        .controllerBuilder()
                        .enableRestStyle()
                        // mapper策略配置
                        .mapperBuilder()
                        .enableMapperAnnotation();
            })
            .execute();
    }
}
