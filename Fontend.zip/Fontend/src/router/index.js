import { createRouter, createWebHistory } from 'vue-router'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'welcome',
      component: () => import('@/views/WelcomeView.vue'),
      children: [
        {
          path: '',
          name: 'welcome-signIn',
          component: () => import('@/components/welcome/LoginPage.vue')
        },
        {
          path: 'signUp',
          name: 'welcome-signUp',
          component: () => import('@/components/welcome/SignUpPage.vue')
        }
      ]
    },
    {
      path: '/index/:customerId',
      name: 'index',
      component: () => import('@/views/IndexView.vue'),
      children: [
        {
          path: '',
          name: 'homePage',
          component: () => import('@/components/customer/HomePage.vue'),
          children: [
            {
              path: '',
              name: 'pieChart',
              component: () => import('@/components/customer/PieChartPage.vue')
            },
            {
              path: '',
              name: 'barChart',
              component: () => import('@/components/customer/BarChartPage.vue')
            }
          ]
        },
        {
          path: 'item',
          name: 'itemHome',
          component: () => import('@/components/item/ItemFindPage.vue'),
          children: [
            {
              path: '',
              name: 'ListPage',
              component: () => import('@/components/item/ItemListPage.vue')
            }
          ]
        },
        {
          path: 'spcart',
          name: 'shoppingCart',
          component: () => import('@/components/customer/ShoppingCartPage.vue')
        },
        {
          path: 'orders',
          name: 'orderList',
          component: () => import('@/components/customer/OrdersInfo.vue')
        },
        {
          path: 'shops',
          name: 'shopList',
          component: () => import('@/components/shop/ShopListPage.vue')
        },
        {
          path: 'shopSetting',
          name: 'shopManagement',
          component: () => import('@/components/shop/ShopManagePage.vue')
        }
      ]
    },

  ]
})

export default router
