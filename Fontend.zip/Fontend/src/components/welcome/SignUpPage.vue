<template>

  <div style="text-align: center; margin: 180px 80px 0 80px" class="sign-class">
    <div style="margin-top: 20px">
      <div style="font-size: 30px">Sign up</div>
      <div style="font-size: 14px; color: grey">Fill in the Infos to sign up</div>
    </div>
    <div style="margin-top: 30px">
      <el-form :label-position="'top'" :model="customer" status-icon :rules="rules" ref="signUpForm" label-width="50px" class="demo-ruleForm">
        <el-form-item label="Telephone" prop="telephone">
          <el-input type="text" v-model="customer.telephone" placeholder="telephone"></el-input>
        </el-form-item>
        <el-form-item label="Address" prop="address">
          <el-input type="text" v-model="customer.address" placeholder="address"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="submitForm('signUpForm')">continue</el-button>
          <el-button @click="resetForm('signUpForm')">reset</el-button>
        </el-form-item>
      </el-form>
    </div>
    <el-divider>
      <span style="color: grey;font-size: 13px">Already have sign up?</span>
    </el-divider>
    <div>
      <el-button style="width: 270px" type="warning" plain @click="router().push('/')">Sign in</el-button>
    </div>
  </div>

</template>

<script>
import router from "@/router";
import {ElMessage} from "element-plus";
import axios from "axios";

export default {
  name: "SignUp",
  data() {
    const validateTelephone = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('please input telephone'));
      }
      callback();
    };
    const validateAddress = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('please input address'));
      }
      callback();
    };
    return {
      customer: {
        telephone: "",
        address: "",
      },
      rules: {
        telephone: [
          { validator: validateTelephone, trigger: 'blur' }
        ],
        address: [
          { validator: validateAddress, trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    router() {
      return router
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          axios({
            method: 'post',
            url: 'https://harryyip.tech/signUp',
            params:{
              telephone: this.customer.telephone,
              address: this.customer.address
            }
          }).then(response => {
            if (response.code === 200) {
              ElMessage.success('Sign up success')
              router.push('/')
            }
          }).catch(error => {
            console.log(error)
          });
          router.push('/')

        } else {
          ElMessage.warning('error submit!!')
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  },
};

</script>

<style scoped>
.sign-class {
  border: 1px solid #999;
  border-radius: 5px;
  padding: 0 20px 20px 20px;
}

</style>