<template>

    <div style="margin: 180px 80px 0 80px" >
      <div class="sign-class">
        <div style="text-align: center; margin-top: 20px">
          <div style="font-size: 30px">Sign in</div>
          <div style="font-size: 14px; color: grey">Fill in the customerID to sign in</div>
        </div>
        <div style="margin-top: 30px">
          <label for="customer" style="left: 50px" >CustomerId</label>
          <el-input v-model="customerId" id="customer" type="text" placeholder="CustomerId" style="margin-top: 5px"></el-input>
        </div>
        <div style="text-align: center; margin-top: 20px">
          <el-button style="width: 270px" type="success" plain @click="signIn()">Continue</el-button>
        </div>
        <el-divider>
          <span style="color: grey;font-size: 13px">New to here?</span>
        </el-divider>
        <div style="text-align: center">
          <el-button style="width: 270px" type="warning" plain @click="router().push('/signUp')">Create new one</el-button>
        </div>
      </div>
    </div>

</template>


<script>
import {ElMessage} from "element-plus";
import router from "@/router";
import {onMounted, ref} from 'vue'
import axios from "axios";

export default {
  name: 'SignIn',
  methods: {
    router() {
      return router
    }
  },
  components: {},
  setup() {
    const flag = ref(true)
    const customerId = ref('');
    const signIn = () => {
      if ( customerId.value === '') {
        ElMessage.warning('Please input customerId')
      } else {
        if (flag.value) {
          flag.value = false
          return ElMessage.warning('this customer has no exist')
        }
        axios({
          method: "post",
          url:'https://harryyip.tech/signIn',
          params:{
            customerId: customerId.value
          }
        }).then(response => {
          if (response.code === 200) {
            console.log(response.msg)
            ElMessage.success('Sign in success.')
            router.push({ path:`/index/${customerId.value}`})
          }
        }).catch(error => {
          console.log(error)
        })
        ElMessage.success('Sign in success.')
        router.push({ path:`/index/${customerId.value}`})
      }


    }

    return {
      customerId, signIn, flag,
    }
  }

}

</script>

<style scoped>
.sign-class {
  border: 1px solid #999;
  border-radius: 5px;
  padding: 0 20px 20px 20px;
}


</style>