<template>
  <el-container>
    <el-main class="search-area">
      <el-input
          v-model="input"
          placeholder="Please input"
          class="input-with-select"
      >
        <template #prepend>
          <el-button :icon="Search" @click="handleSearch(select)"/>
        </template>
        <template #append>
          <el-select v-model="select" placeholder="Select" style="width: 130px">
            <el-option label="ItemKeyword" value="1" />
            <el-option label="ShopId" value="2" />
          </el-select>
        </template>
      </el-input>
    </el-main>
  </el-container>
  <div class="common-layout">
    <el-container>
      <el-main>
        <router-view :itemData="itemData" />
      </el-main>
      <el-footer style="margin: 0 100px">
        <el-divider>
          <span style="color: grey;font-size: 13px">
             <el-link :href="`/index/${$route.params.customerId}`">return to home page</el-link>
          </span>
        </el-divider>
      </el-footer>
    </el-container>
  </div>

</template>

<script>
import {Search} from "@element-plus/icons-vue";
import router from "@/router";
import axios from "axios";
import {ref} from 'vue'

export default {
  name: "ItemFindPage",
  methods: {
    router() {
      return router
    },
  },
  computed: {
    Search() {
      return Search
    }
  },
  setup() {
    const input = ref('');
    const select = ref('');
    const itemData = ref([]);

    const handleSearch = (select) => {
      switch (select) {
        case '1':
          itemData.value = [
            {
              "itemId": 1,
              "shopId": 2,
              "name": "testItem",
              "price": 10,
              "keyword1": null,
              "keyword2": "5",
              "keyword3": null
            }
          ]
          axios({
            methods: "get",
            url: 'https://harryyip.tech/item/searchItems',
            params: {
              input: input.value
            }
          }).then(response => {
            if (response.code === 200) {
              itemData.value = response.obj;
            }
          }).catch(error => {
            console.log(error)
          });
          break;
        case '2':
          itemData.value = [
            {
              "itemId": 2,
              "shopId": 1,
              "name": "item2",
              "price": 10,
              "keyword1": null,
              "keyword2": null,
              "keyword3": null
            },
            {
              "itemId": 3,
              "shopId": 1,
              "name": "item3",
              "price": 11.111111,
              "keyword1": null,
              "keyword2": null,
              "keyword3": null
            }
          ]
          axios({
            methods: "get",
            url: `https://harryyip.tech/item/showItems/${input.value}` ,
          }).then(response => {
            if (response.code === 200) {
              itemData.value = response.obj;
            }
          }).catch(error => {
            console.log(error)
          });
          break;
      }

    }

    return {
        input, select, itemData, handleSearch
      }
    }

}
</script>

<style scoped>
.input-with-select .el-input-group__prepend {
  background-color: var(--el-fill-color-blank);
}
.search-area{
  margin: 20px 200px;
}
.el-link .el-icon--right.el-icon {
  vertical-align: text-bottom;
}

</style>