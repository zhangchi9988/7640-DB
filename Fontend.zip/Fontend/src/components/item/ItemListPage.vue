<template>
  <el-table :data="itemData" height="550" style="width: 100%">
    <el-table-column prop="name" label="itemName" width="130" />
    <el-table-column prop="price" label="price" width="130"/>
    <el-table-column prop="shopId" label="shopId" width="130" />
    <el-table-column v-if="itemData.keyword1 !== null"
        prop="keyword1"
        label="keyword1"
        width="150">
    </el-table-column>
    <el-table-column v-if="itemData.keyword2 !== null"
        prop="keyword2"
        label="keyword2"
        width="150">
    </el-table-column>
    <el-table-column v-if="itemData.keyword3 !== null"
        prop="keyword3"
        label="keyword3"
        width="150">
    </el-table-column>
    <el-table-column label="Operations">
      <template #default="scope">
        <el-button size="small" @click="handleItem(scope.$index, scope.row)">
          <el-icon><ShoppingCart /></el-icon>
          <span>Add to shoppingCart</span>
        </el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import {ShoppingCart} from "@element-plus/icons-vue";
import {ElNotification} from "element-plus";
import {h} from "vue";

export default {
  name: "ItemList",
  props:['itemData'],
  components: {ShoppingCart},
  data() {
    return {
    }
  },
  methods: {
    handleItem : (index, row)=> {
      ElNotification({
        title: 'Add success.',
        message: h('i', { style: 'color: teal' }, 'Item: '+row.name+' added.'),
      })
      console.log(row)
    }
  }
}
</script>

<style scoped>

</style>