<template>
  <el-scrollbar>
    <el-container style="height: 30%">
      <el-main>
        <div class="customer-area">
          <el-descriptions title="User Info">
            <el-descriptions-item label="customerId">{{customerId}}</el-descriptions-item>
            <el-descriptions-item label="Telephone">45454545</el-descriptions-item>
            <el-descriptions-item label="Remarks">
              <el-tag size="small">customer</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="Address"
            >hkhkhk</el-descriptions-item
            >
          </el-descriptions>
        </div>
      </el-main>
    </el-container>
    <el-container style="height: 30%">
      <el-main class="statistic-area">
        <div style="margin: 0 0 0 200px">
          <el-row :gutter="18">
          <el-col :span="6">
            <div class="statistic-card">
              <el-statistic :value="0">
                <template #title>
                  <div style="display: inline-flex; align-items: center">
                    Shop Items
                  </div>
                </template>
              </el-statistic>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="statistic-card">
              <el-statistic :value="0">
                <template #title>
                  <div style="display: inline-flex; align-items: center">
                    Item sells
                  </div>
                </template>
              </el-statistic>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="statistic-card">
              <el-statistic :value="0">
                <template #title>
                  <div style="display: inline-flex; align-items: center">
                    Orders
                  </div>
                </template>
              </el-statistic>
            </div>
          </el-col>
        </el-row>
        </div>
      </el-main>
    </el-container>
    <el-container style="height: 40%">
      <el-main class="statistic-area2">
        <el-tabs type="border-card">
          <el-tab-pane label="Item">
            <PieChartPage></PieChartPage>
          </el-tab-pane>
          <el-tab-pane label="Shop">
            <BarChartPage></BarChartPage>
          </el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </el-scrollbar>
</template>


<script>
import PieChartPage from "@/components/customer/PieChartPage.vue";
import BarChartPage from "@/components/customer/BarChartPage.vue";
import {onMounted} from "vue";

export default {
  name: 'homePage',
  props:['customerId'],
  components: {BarChartPage, PieChartPage},


}

</script>

<style scoped>

.el-statistic {
  --el-statistic-content-font-size: 28px;
}
.statistic-card {
  margin: 0 50px 0 50px;
  height: 30%;
  padding: 0;
  border-radius: 4px;
  background-color: white;
}
.customer-area {
  margin: 30px 90px 0 140px;
  width: 800px;
  border: 1px solid #f1f1f1;
  border-radius: 5px;
  padding: 60px;
}
.statistic-area {
  border: 1px solid #f1f1f1;
}
.statistic-area2 {
  margin: 0 160px 0 150px;
}

</style>