<template>
  <div id="chart">
    <apexchart type="pie" width="380" :options="chartOptions" :series="series"></apexchart>
  </div>
</template>

<script>
export default {
  name: "PieChartPage",
  data() {
    const series = [44, 55, 13, 43, 22];
    const chartOptions = {
      chart: {
        width: 380,
        type: 'pie',
      },
      labels: ['Item-03', 'Item-07', 'Item-04', 'Item-01', 'Item-05'],
      responsive: [{
        breakpoint: 480,
        options: {
          chart: {
            width: 200
          },
          legend: {
            position: 'bottom'
          }
        }
      }]
    };
    return {
      series, chartOptions
    }
  },
}
</script>

<style scoped>

</style>