<template>
  <el-container>
    <el-main>
      <div class="info-area">
        <el-table
            ref="multipleTableRef"
            :data="tableData"
            style="width: 100%"
            height="550"
            @selection-change="handleSelectionChange"
        >
          <el-table-column type="selection" width="55" />
          <el-table-column prop="name" label="itemName" width="130" />
          <el-table-column prop="price" label="price" width="130"/>
          <el-table-column prop="shopId" label="shopId" width="130" />
          <el-table-column prop="keyword1"
                           label="keyword1"
                           width="150">
          </el-table-column>
          <el-table-column prop="keyword2"
                           label="keyword2"
                           width="150">
          </el-table-column>
          <el-table-column prop="keyword3"
                           label="keyword3"
                           width="150">
          </el-table-column>
        </el-table>
        <div style="margin-top: 20px">
          <el-popconfirm
              title="Are you sure to cancel these orders?"
              @confirm="toggleSelection(multipleSelection)"
              @cancel=""
          >
            <template #reference>
              <el-button>Cancel order(s)</el-button
              >
            </template>
          </el-popconfirm>
          <el-button @click="reset()">Clear selection</el-button>
          <el-button @click="update()">update</el-button>
        </div>
      </div>
    </el-main>
    <el-footer style="margin: 0 100px">
      <el-divider>
        <span style="color: grey;font-size: 13px">
           <el-link :href="`/index/${$route.params.customerId}`">return to homepage</el-link>
        </span>
      </el-divider>
    </el-footer>
  </el-container>
</template>

<script lang="ts" setup>
import { ref} from 'vue'
import {ElMessage, ElTable} from 'element-plus'

interface Item {
  itemName: string
  price: number
  shopId: number
  keyword1: string
}

const tableData = ref([])

const multipleTableRef = ref<InstanceType<typeof ElTable>>()
const multipleSelection = ref<Item[]>([])
const toggleSelection = (rows?: Item[]) => {
  for (let i = 0; i < rows.length; i++) {
    console.log(rows[i])
  }
  tableData.value = []
  ElMessage.success('cancel success')
}
const handleSelectionChange = (val: Item[]) => {
  multipleSelection.value = val
}

const reset = (rows?: Item[]) => {
  if(!rows) multipleTableRef.value!.clearSelection()
}

const update = () => {
  tableData.value = [
    {
      "itemId": 1,
      "shopId": 2,
      "name": "testItem",
      "price": 10,
      "keyword1": null,
      "keyword2": "5",
      "keyword3": null
    }
  ]
  ElMessage.success('updated')
}



</script>

<style scoped>
.info-area {
  border: 1px solid #f1f1f1;
  margin: 20px 100px;
}

</style>
