<template>

  <el-container>
    <el-main>
      <div style="text-align: center" class="transfer-area">
        <div style="text-align: center; margin: 10px">
      <el-transfer
          v-model="Value"
          style="text-align: left; display: inline-block"
          filterable
          :titles="['ShoppingCart', 'Order']"
          :button-texts="['remove item', 'Add to orders']"
          :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}',
        }"
          :data="data"
          @change="handleChange"
      >
        <template #default="{ option }">
          <span>{{ option.key }} - {{ option.label }}</span>
        </template>
        <template #left-footer>
          <el-button class="transfer-footer" size="small" type="danger">delete</el-button>
        </template>
        <template #right-footer>
          <el-button class="transfer-footer" size="small" type="danger">delete</el-button>
          <el-button class="transfer-footer" size="small" type="success">ordering</el-button>
        </template>
      </el-transfer>
      <el-button style="margin: 0 120px" type="info" @click="router.push({path:`/index/${$route.params.customerId}/orders`})">
        <el-icon><View /></el-icon>
        <span>Orders-Info</span>
      </el-button>
          <el-button type="text" @click="updateHandle()">update</el-button>
    </div>
      </div>
    </el-main>
  </el-container>
  <div class="common-layout">
    <el-container>
      <el-main>
        <div style="margin: 10px 150px" m="t-4">
          <el-carousel trigger="click" height="150px">
            <el-carousel-item v-for="item in groupInfo" :key="item.id">
              <h3 class="small justify-center" text="2xl">{{ item.name }} - {{ item.id }}</h3>
            </el-carousel-item>
          </el-carousel>
        </div>
      </el-main>
      <el-footer style="margin: 0 100px">
        <el-divider>
            <span style="color: grey;font-size: 13px">
               <el-link :href="`/index/${$route.params.customerId}`">return to home page</el-link>
            </span>
        </el-divider>
      </el-footer>
    </el-container>
  </div>


</template>


<script lang="ts" setup>
  import { ref } from 'vue'
  import {View} from "@element-plus/icons-vue";
  import router from "../../router";

  interface Option {
  key: number
  label: string
}

  const groupInfo = [
    {
      name:'YE Hanyi',
      id: '22414495'
    },
    {
      name:'ZHANG Chi',
      id: '22407987'
    },
    {
      name:'WU Chen',
      id: '22443606'
    },
    {
      name:'QIU Chen',
      id: '22427481'
    }
  ]
  const generateData = (): Option[] => {
  const data: Option[] = []
  for (let i = 1; i <= 15; i++) {
  data.push({
  key: i,
  label: `Option ${i}`,
})
}
  return data
}

  const data = ref(generateData())
  const Value = ref([1])
  const handleChange = (
  value: number | string,
  direction: 'left' | 'right',
  movedKeys: string[] | number[]
  ) => {
  console.log(value, direction, movedKeys)
}

  const updateHandle = () => {

  }
</script>


<style>
.transfer-footer {
  margin-left: 15px;
  padding: 6px 5px;
}
.transfer-area {
  border: 1px solid #f1f1f1;
  margin: 30px 100px 0 100px;
}
.demonstration {
  color: var(--el-text-color-secondary);
}

.el-carousel__item h3 {
  color: #475669;
  opacity: 0.75;
  line-height: 150px;
  margin: 0;
  text-align: center;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}
</style>