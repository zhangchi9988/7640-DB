<template>
  <el-container>
    <el-main>
      <el-row>
        <el-form v-model="shopInfo">
          <el-form-item>
            <el-button
                type="success"
                style="margin-top: 18px;"
                @click="addShop()"
            >add shop</el-button>
          </el-form-item>
          <el-form-item label="shopName" prop="shopName">
            <el-input type="text" v-model="shopInfo.shopName"></el-input>
          </el-form-item>
          <el-form-item label="location" prop="location">
            <el-input type="text" v-model="shopInfo.location"></el-input>
          </el-form-item>
        </el-form>
      </el-row>
      <el-divider />
    </el-main>
  </el-container>
  <el-container>
    <el-main class="main-area">
      <h1 v-if="flag">You don't have any shop</h1>
      <div v-if="!flag">
        <el-card class="box-card" v-for="Info in shopInfos" >
          <template #header>
            <div class="card-header">
              <span>Shop</span>
              <el-button text style="margin-left: 700px" @click="drawer = true"
              >Add Items
              </el-button>
              <el-button text @click="updateList()"
              >Update
              </el-button>
            </div>
          </template>
          <div class="text item">Shop name: {{Info.shopName}}</div>
          <div class="text item">location: {{Info.location}}</div>
          <div>
            <el-collapse v-model="activeNames">
              <el-collapse-item title="Item List" name="1">
                <el-table :data="tableData" height="550" style="width: 100%">
                  <el-table-column prop="name" label="name" width="130" />
                  <el-table-column prop="price" label="price" width="130"/>
                  <el-table-column prop="shopId" label="shopId" width="130" />
                  <el-table-column prop="keyword1"
                                   label="keyword1"
                                   width="150">
                  </el-table-column>
                  <el-table-column prop="keyword2"
                                   label="keyword2"
                                   width="150">
                  </el-table-column>
                  <el-table-column prop="keyword3"
                                   label="keyword3"
                                   width="150">
                  </el-table-column>
                </el-table>
              </el-collapse-item>
            </el-collapse>
          </div>
        </el-card>
      </div>

      <el-drawer v-model="drawer" title="I am the title" :with-header="false">
        <div style="margin: 20px" />
        <el-form
            :label-position="'top'"
            label-width="100px"
            style="max-width: 460px"
            v-model="itemInfo"
        >
          <el-form-item label="itemName(*)">
            <el-input type="text" v-model="itemInfo.itemName"></el-input>
          </el-form-item>
          <el-form-item label="price(*)">
            <el-input type="text" v-model="itemInfo.price"></el-input>
          </el-form-item>
          <el-form-item label="keyword1">
            <el-input type="text" v-model="itemInfo.keyword1"></el-input>
          </el-form-item>
          <el-form-item label="keyword2">
            <el-input type="text" v-model="itemInfo.keyword2"></el-input>
          </el-form-item>
          <el-form-item label="keyword3">
            <el-input type="text" v-model="itemInfo.keyword3"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="success" @click="addItem()">
              continue
            </el-button>
          </el-form-item>
        </el-form>
      </el-drawer>

    </el-main>
  </el-container>

</template>

<script>
import {Plus} from "@element-plus/icons-vue";
import {ref} from "vue";
import {ElMessage} from "element-plus";
import axios from "axios";

export default {
  name: "ShopManagePage",
  components: {Plus},
  setup() {
    const shopInfo = ref({});
    const itemInfo = ref({
      itemName: '',
      price:'',
      keyword1:'',
      keyword2:'',
      keyword3:'',
    });
    const flag = ref(true);
    const shopInfos = ref([]);
    const drawer = ref(false);
    const activeNames = ref(['1']);
    const shopId = ref('')
    const tableData = ref([])
    const item = ref({shopId:-1})

    const updateList = () => {
      getShopId()
      axios({
        methods: "get",
        url: `https://harryyip.tech/item/showItems/${shopId.value}` ,
      }).then(response => {
        if (response.code === 200) {
          tableData.value = response.obj;
        }
      }).catch(error => {
        console.log(error)
      });
      ElMessage.success('updated')
      if (item.value.shopId === -1){
        return
      }
      tableData.value.push(item.value)
      item.value = {shopId: -1}

    }

    const getShopId = () => {
      axios({
        method: "get",
        url: 'https://harryyip.tech/shop/showShops',
      }).then(response => {
        if (response.code === 200) {
          this.shopData = response.obj;
          for (const shop in response.obj) {
            if (shop.shopName === shopInfos.value[0].shopName) {
              shopId.value = shop.shopId
            }
          }
        }
      }).catch(error => {
        console.log(error)
      })
      shopId.value = 3
    }

    const addShop = () => {
      if (shopInfo.value.hasOwnProperty('shopName') &&
          shopInfo.value.hasOwnProperty('location')) {
        if (shopInfos.value.length !== 0) {
          return ElMessage.warning('You can only host one shop at a time.')
        }
        shopInfos.value.push({
          shopName: shopInfo.value.shopName,
          location: shopInfo.value.location
        });
        flag.value = false;
        axios({
          method: "post",
          url: 'https://harryyip.tech/shop/addShop',
          params: {
            shopName: shopInfo.value.shopName,
            location: shopInfo.value.location
          }
        }).then(response => {
          if (response.code === 200) {
            ElMessage.success('Shop add success')
          }
        }).catch(error => {
          console.log(error)
        })
        ElMessage.success('Shop add success')

      } else {
        ElMessage.warning('Please input both name and location of your shop.')
      }
    }

    const addItem = () => {
      if (itemInfo.value.itemName === '' ||
      itemInfo.value.price === '') {
        ElMessage.warning('please input both itemName and price.')
      } else {
        axios({
          method: "post",
          url: 'https://harryyip.tech/item/addItem',
          params: {
            shopId: shopId.value,
            itemName: itemInfo.value.itemName,
            price: itemInfo.value.price,
            keyword1: itemInfo.value.keyword1
          }
        }).then(response => {
          if (response.code === 200) {
            ElMessage.success('add success')
          }
        }).catch(error => {
          console.log(error)
        })
        item.value = {
          name: itemInfo.value.itemName,
          price: itemInfo.value.price,
          shopId: 3,
          keyword1: itemInfo.value.keyword1
        }
        itemInfo.value.itemName = ''
        itemInfo.value.price = ''
        itemInfo.value.keyword1 = ''
        ElMessage.success('add success')




      }
    }

    return {
      flag, addShop, shopInfos, drawer, shopInfo, activeNames, tableData,
      itemInfo, addItem, getShopId, shopId, updateList
    }
  },
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.box-card {
  width: 1000px;
  margin-top: 50px;
}
.main-area {
  margin: 0 100px;
}
.el-row {
  margin-bottom: 20px;
}
.el-row:last-child {
  margin-bottom: 0;
}
.el-col {
  border-radius: 4px;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
}

</style>