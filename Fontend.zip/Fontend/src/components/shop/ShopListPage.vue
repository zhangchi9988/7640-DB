<template>

  <el-container>
    <div class="table-area">
      <h1 style="text-align: center; text-shadow: black;font-size: 20px" >Shops List</h1>
      <el-table :data="shopData" height="550" style="width: 100%">
        <el-table-column prop="shopName" label="shopName" width="130" />
        <el-table-column prop="location" label="location" width="130"/>
        <el-table-column label="Operations">
          <template #default="scope">
            <el-button size="small" @click="dialogTableHandle(scope.row.shopId)">
              <el-icon><InfoFilled /></el-icon>
              <span>Details</span>
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog v-model="dialogTableVisible" title="Items info in this shop">
      <el-table :data="itemData">
        <el-table-column prop="name" label="itemName" width="130" />
        <el-table-column prop="price" label="price" width="130"/>
        <el-table-column prop="shopId" label="shopId" width="130" />
        <el-table-column prop="keyword1"
                         label="keyword1"
                         width="150">
        </el-table-column>
        <el-table-column prop="keyword2"
                         label="keyword2"
                         width="150">
        </el-table-column>
        <el-table-column prop="keyword3"
                         label="keyword3"
                         width="150">
        </el-table-column>
      </el-table>
    </el-dialog>
    </div>
    <el-footer style="margin: 20px 100px">
      <el-divider>
          <span style="color: grey;font-size: 13px">
             <el-link :href="`/index/${$route.params.customerId}`">return to home page</el-link>
          </span>
      </el-divider>
    </el-footer>
  </el-container>


</template>

<script>
import {InfoFilled} from "@element-plus/icons-vue";
import axios from "axios";
import {onMounted, ref} from "vue";

export default {
  name: "ShopListPage",
  components: {InfoFilled},
  setup() {
    const dialogTableVisible = ref(false)
    const shopData = ref([
      {
        "shopId": 1,
        "shopName": "testshop",
        "rating": 0,
        "location": "testshop"
      },
      {
        "shopId": 2,
        "shopName": "test2 ",
        "rating": 0,
        "location": "beijing"
      }
    ])
    const itemData = ref([])
    const tableData = ref([
      {
        shopName: 'Ass',
        location: 'CN'
      },
      {
        shopName: 'ZAS',
        location: 'AM',
      },
      {
        shopName: 'FAA',
        location: 'UK'
      },
      {
        shopName: 'WSS',
        location: 'TW',
      },{
        shopName: 'PAA',
        location: 'HK'
      },
      {
        shopName: 'WFZ',
        location: 'CN',
      },
      {
        shopName: 'Ass',
        location: 'CN'
      },
      {
        shopName: 'ZAS',
        location: 'AM',
      },
      {
        shopName: 'FAA',
        location: 'UK'
      },
      {
        shopName: 'WSS',
        location: 'TW',
      },{
        shopName: 'PAA',
        location: 'HK'
      },
      {
        shopName: 'WFZ',
        location: 'CN',
      },
      {
        shopName: 'Ass',
        location: 'CN'
      },
      {
        shopName: 'ZAS',
        location: 'AM',
      },
      {
        shopName: 'FAA',
        location: 'UK'
      },
      {
        shopName: 'WSS',
        location: 'TW',
      },{
        shopName: 'PAA',
        location: 'HK'
      },
      {
        shopName: 'WFZ',
        location: 'CN',
      },
      {
        shopName: 'Ass',
        location: 'CN'
      },
      {
        shopName: 'ZAS',
        location: 'AM',
      },
      {
        shopName: 'FAA',
        location: 'UK'
      },
      {
        shopName: 'WSS',
        location: 'TW',
      },{
        shopName: 'PAA',
        location: 'HK'
      },
      {
        shopName: 'WFZ',
        location: 'CN',
      },
    ])
    const gridData = ref([
      {
        itemName: 'Glass',
        price: 30.0,
        shopId: 6,
        keywords: [
          'home',
          'work',
        ]
      },
      {
        itemName: 'Glass',
        price: 30.0,
        shopId: 6,
        keywords: [
          'home',
          'work',
        ]
      },
      {
        itemName: 'Glass',
        price: 30.0,
        shopId: 6,
        keywords: [
          'home',
          'work',
        ]
      },
      {
        itemName: 'Glass',
        price: 30.0,
        shopId: 6,
        keywords: [
          'home',
          'work',
        ]
      },
      {
        itemName: 'Glass',
        price: 30.0,
        shopId: 6,
        keywords: [
          'home',
          'work',
        ]
      },
      {
        itemName: 'Glass',
        price: 30.0,
        shopId: 6,
        keywords: [
          'home',
          'work',
        ]
      },
    ])

    const dialogTableHandle = (shopId) => {
      dialogTableVisible.value = true;
      switch (shopId) {
        case 1:
          itemData.value = [
            {
              "itemId": 2,
              "shopId": 1,
              "name": "item2",
              "price": 10,
              "keyword1": null,
              "keyword2": null,
              "keyword3": null
            },
            {
              "itemId": 3,
              "shopId": 1,
              "name": "item3",
              "price": 11.111111,
              "keyword1": null,
              "keyword2": null,
              "keyword3": null
            }
          ]
          break;
        case 2:
          itemData.value = [
            {
              "itemId": 1,
              "shopId": 2,
              "name": "testItem",
              "price": 10,
              "keyword1": null,
              "keyword2": "5",
              "keyword3": null
            }
          ]
          break;
      }
      axios({
        methods: "get",
        url: `https://harryyip.tech/item/showItems/${shopId}`,
      }).then(response => {
        if (response.code === 200) {
          itemData.value = response.obj
        }
      }).catch(error => {
        console.log(error)
      });
    }

    onMounted(() => {
        axios({
          method: "get",
          url: 'https://harryyip.tech/shop/showShops',
        }).then(response => {
          if (response.code === 200) {
            this.shopData = response.obj;
          }
        }).catch(error => {
          console.log(error)
        })
    })

    return{
      dialogTableVisible, dialogTableHandle, tableData, gridData, shopData, itemData
    }
  },
}
</script>

<style scoped>
.table-area{
  border: 1px solid #f1f1f1;
  margin: 30px 100px 20px 100px ;
}

</style>