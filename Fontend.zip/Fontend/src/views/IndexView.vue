<template>
  <el-container class="layout-container-demo" style="height: 500px">
    <el-aside width="200px" style="height: 100vh">
      <el-scrollbar>
        <el-menu default-active="1">
          <el-menu-item @click="router().push({path:`/index/${$route.params.customerId}`})">
            <el-icon><House /></el-icon>
            <span>HomePage</span>
          </el-menu-item>
          <el-menu-item @click="router().push({path:`/index/${$route.params.customerId}/item`})">
            <el-icon><Tickets /></el-icon>
            <span>Item service</span>
          </el-menu-item>
          <el-sub-menu >
            <template #title>
              <el-icon><Goods /></el-icon>
              <span>Shop service</span>
            </template>
            <el-menu-item @click="router().push({path:`/index/${$route.params.customerId}/shops`})">
              <el-icon><Compass /></el-icon>
              <span>explore shops</span>
            </el-menu-item>
            <el-menu-item @click="router().push({path:`/index/${$route.params.customerId}/shopSetting`})">
              <el-icon><Tools /></el-icon>
              <span>shop settings</span>
            </el-menu-item>
          </el-sub-menu>
        </el-menu>
      </el-scrollbar>
    </el-aside>

    <el-container style="height: 100vh">
      <el-header style="text-align: right; font-size: 12px">
        <div class="toolbar">
          <el-dropdown>
            <el-icon style="margin-right: 8px; margin-top: 1px"><setting/></el-icon>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="router().push({path:`/index/${$route.params.customerId}`})">Homepage</el-dropdown-item>
                <el-dropdown-item @click="router().push({path:`/index/${$route.params.customerId}/orders`})">purchases&orders</el-dropdown-item>
                <el-dropdown-item @click="logOut()">Sign out</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          <span>customer-{{$route.params.customerId}}</span>
        </div>
      </el-header>
      <el-main>
        <router-view :customerId="$route.params.customerId"/>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>

import {Compass, Edit, Goods, House, Setting, Tickets, Tools} from "@element-plus/icons-vue";
import HomePage from "@/components/customer/HomePage.vue";
import router from "@/router";
import axios from "axios";
import {defineComponent, onMounted, ref} from "vue";
import {ElMessage} from "element-plus";

  export default defineComponent ({
    name: 'index',
    methods: {
      router() {
        return router
      }
    },
    components: {Compass, Edit, Tools, Tickets, Setting, Goods, House, HomePage},
    setup() {
      const logOut = () => {
        axios({
          method: 'post',
          url: 'https://harryyip.tech/logOut',
        }).then((response) => {
          console.log(response)
        }).catch((error) => {
          console.log(error)
        });
        ElMessage.success('login out success')
        router.push('/')
      };

      return {
        logOut,
      }
    }
  })
</script>

<style scoped>
.layout-container-demo .el-header {
  position: relative;
  background-color: var(--el-color-primary-light-7);
  color: var(--el-text-color-primary);
}
.layout-container-demo .el-aside {
  color: var(--el-text-color-primary);
  background: var(--el-color-primary-light-8);
}
.layout-container-demo .el-menu {
  border-right: none;
}
.layout-container-demo .el-main {
  padding: 0;
}
.layout-container-demo .toolbar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  right: 20px;
}
</style>