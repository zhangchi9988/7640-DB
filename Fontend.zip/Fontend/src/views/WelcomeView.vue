<template>
  <div style="width: 100vw; height: 100vh;overflow: hidden; display: flex">
    <div style="flex: 1">
      <el-image style="width: 100%; height: 100%" fit="cover"
                src="https://www.ionos.com/digitalguide/fileadmin/DigitalGuide/Teaser/online-shopping-t.jpg"/>
    </div>
    <div class="welcome-title">
      <div style="font-size: 50px; font-weight: bold">COMP7640 G32</div>
      <div style="margin-top: 20px">YE Hanyi    22414495</div>
      <div style="margin-top: 20px">ZHANG Chi    22407987</div>
      <div style="margin-top: 20px">WU Chen    22443606</div>
      <div style="margin-top: 20px">QIU Chen    22427481</div>
    </div>
    <div style="width: 500px;background-color: white">
      <router-view />
    </div>
  </div>

</template>

<script>


export default {
  name: 'welcomeView',
}


</script>

<style scoped>
.welcome-title {
  position: absolute;
  bottom: 30px;
  left: 30px;
  color: white;
  text-shadow: 0 0 10px black;
}

</style>